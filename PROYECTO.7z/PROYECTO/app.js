const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const mysql = require('mysql');
const config = require('./config');

const app = express();
const port = 3000;

// Configurar middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'tu_secreto', resave: true, saveUninitialized: true }));

const connection = mysql.createConnection(config);
connection.connect();

// Ruta para mostrar el formulario de Registro
app.get('/registro', (req, res) => {
    res.sendFile(__dirname + '/registro.html');
});

// Ruta para procesar el Registro
app.post('/registro', (req, res) => {
    // Aquí implementaremos el código de registro
});

// Ruta para mostrar el formulario de Login
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/login.html');
});

// Ruta para procesar el Login
app.post('/login', (req, res) => {
    // Aquí implementaremos el código de login
});

app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});






/*
    INSERTAR A UN NUEVO USUARIO EN LA BASE DE DATOS
*/
app.post('/registro', (req, res) => {
    const { username, email, password } = req.body;

    const hash = bcrypt.hashSync(password, 10);

    const query = 'INSERT INTO usuarios (username, email, password) VALUES (?, ?, ?)';
    connection.query(query, [username, email, hash], (error, results) => {
        if (error) {
            if (error.code === 'ER_DUP_ENTRY') {
                return res.send('El email o el username ya están registrados.');
            }
            return res.send('Error al registrar el usuario.');
        }
        res.send('Usuario registrado correctamente.');
    });
});


/*
    VERIFICAR CREDENCIALES Y ESTABLECER UNA CONEXIÓN
*/
app.post('/login', (req, res) => {
    const { email, password } = req.body;

    const query = 'SELECT * FROM usuarios WHERE email = ?';
    connection.query(query, [email], (error, results) => {
        if (error || !results.length || !bcrypt.compareSync(password, results[0].password)) {
            return res.send('Credenciales incorrectas. Por favor, inténtalo de nuevo.');
        }
        req.session.loggedin = true;
        req.session.username = results[0].username;
        res.redirect('/dashboard'); // AQUI REDIRECCIONARÁ A LA SECCIÓN PRINCIPAL DESPUÉS DEL LOGIN
    });
});

