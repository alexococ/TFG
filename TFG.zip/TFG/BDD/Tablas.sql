/*

----------------------------------------------------------------------------------------------------------------------------------------
1) Crear Tareas:

    El dueño del proyecto puede crear tareas con nombre, descripción, fecha de inicio y fecha de vencimiento.

----------------------------------------------------------------------------------------------------------------------------------------

2) Asignar Categorías a Tareas:

    El dueño del proyecto puede asignar categorías a las tareas para clasificarlas (Front-End, Back-End, Base de datos, etc.).

----------------------------------------------------------------------------------------------------------------------------------------

3) Asignar Etiquetas a Tareas:

    El dueño del proyecto puede asignar etiquetas a las tareas para indicar urgencia o relevancia.

----------------------------------------------------------------------------------------------------------------------------------------

4) Invitar Usuarios:

    El dueño del proyecto puede invitar a otros usuarios a formar parte del proyecto, aunque no sean administradores.

----------------------------------------------------------------------------------------------------------------------------------------

5) Gestionar Roles:

    El dueño del proyecto puede crear, modificar, eliminar y asignar roles a los usuarios en el proyecto.

----------------------------------------------------------------------------------------------------------------------------------------

6) Validar Tareas:

    El dueño del proyecto debe validar las tareas finalizadas para que el porcentaje de progreso del proyecto avance.

----------------------------------------------------------------------------------------------------------------------------------------

7) Definir Permisos y Roles:

    Todos los usuarios deben tener un rol asignado, y cada rol tiene permisos específicos (por ejemplo, crear tareas pero no validarlas).

----------------------------------------------------------------------------------------------------------------------------------------

8) Rol "Superadmin":

    El administrador (dueño del proyecto) tiene un rol especial llamado "superadmin" que otorga acceso completo a todas las funciones del proyecto.

----------------------------------------------------------------------------------------------------------------------------------------

9) Chat en Tiempo Real:

    Los usuarios dentro del proyecto pueden comunicarse en tiempo real a través de un chat para una comunicación rápida y efectiva.

----------------------------------------------------------------------------------------------------------------------------------------

*/











/* CREACIÓN DE TABLAS (PRUEBA) PARA LA APLICACIÓN */



-- TABLA DE LOS USUARIOS
CREATE TABLE Usuarios (
    id_Usuario INT AUTO_INCREMENT PRIMARY KEY,
    Nombre_Usuario VARCHAR(50) NOT NULL,
    Contraseña VARCHAR(50) NOT NULL,
    Email VARCHAR(100) NOT NULL
);







/* ------------ GESTION DE LOS PROYECTOS Y SUS FUNCIONES DENTRO DE EL ------------ */


-- TABLA DE LOS PROYECTOS
CREATE TABLE Proyectos (
    id_Proyecto INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Nombre_Proyecto VARCHAR(50) NOT NULL,
    Descripcion VARCHAR(200),
    id_Usuario INT,
    Porcentaje_Avance INT DEFAULT 0, -- Porcentaje de avance del proyecto
    FOREIGN KEY (id_Creador) REFERENCES Usuarios(id_Usuario)
);


-- TABLA DE LOS USUARIOS QUE FORMAN PARTE DEL PROYECTO
CREATE TABLE Usuarios_Proyecto (
    id_Usuario_Proyecto INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    id_Usuario INT,
    id_Proyecto INT,
    id_Rol INT,
    FOREIGN KEY (id_Usuario) REFERENCES Usuarios(id_Usuario),
    FOREIGN KEY (ID_Proyecto) REFERENCES Proyectos(id_Proyecto),
    FOREIGN KEY (id_Rol) REFERENCES Roles(id_Rol)
);

CREATE TABLE Mensajes (
    id_Mensaje INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Contenido TEXT,
    id_Usuario_Envia INT,
    id_Usuario_Recibe INT,
    id_Proyecto INT,
    Fecha_Envio DATETIME,
    FOREIGN KEY (id_Usuario_Envia) REFERENCES Usuarios(id_Usuario),
    FOREIGN KEY (id_Usuario_Recibe) REFERENCES Usuarios(id_Usuario),
    FOREIGN KEY (id_Proyecto) REFERENCES Proyectos(id_Proyecto)
);








-- TABLA DE CATEGORIAS (FRONT-END // BACK-END // BDD...)
CREATE TABLE Categorias (
    id_Categoria INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Nombre_Categoria VARCHAR(50) NOT NULL,
    ID_Proyecto INT,
    FOREIGN KEY (id_Proyecto) REFERENCES Proyectos(id_Proyecto)
);


-- TABLA PARA LAS TAREAS (OBJETIVOS PARA QUE EL PROYECTO SALGA CORRECTAMENTE Y SE REFLEJEN LOS PASOS QUE SE HAN SEGUIDO)
CREATE TABLE Tareas (
    ID_Tarea INT AUTO_INCREMENT PRIMARY KEY,
    Titulo VARCHAR(100),
    Descripcion TEXT,
    Fecha_Inicio DATE,
    Fecha_Vencimiento DATE,
    id_Proyecto INT,
    id_Categoria INT,
    id_Etiqueta INT,
    id_Usuario_Asignado INT, -- ID del usuario al que se asigna la tarea
    FOREIGN KEY (id_Proyecto) REFERENCES Proyectos(id_Proyecto),
    FOREIGN KEY (id_Categoria) REFERENCES Categorias(id_Categoria),
    FOREIGN KEY (id_Etiqueta) REFERENCES Etiquetas(id_Etiqueta),
    FOREIGN KEY (id_Usuario_Asignado) REFERENCES Usuarios(id_Usuario)
);


-- TABLA DE ETIQUETAS PARA LAS TAREAS (URGENTE, POCO URGENTE...)
CREATE TABLE Etiquetas (
    id_Etiqueta INT AUTO_INCREMENT PRIMARY KEY,
    Nombre_Etiqueta VARCHAR(50),
    Descripcion_Etiqueta TEXT
);








-- TABLAS DE ROLES Y PERMISOS QUE TENDRÁN LOS USUARIOS DENTRO DEL PROYECTO
CREATE TABLE Roles (
    id_Rol INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Nombre_Rol VARCHAR(50) NOT NULL,
    Descripcion_Rol TEXT
);


CREATE TABLE Permisos (
    id_Permiso INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    Nombre_Permiso VARCHAR(50) NOT NULL,
    Descripcion_Permiso TEXT
);


CREATE TABLE Roles_Permisos (
    id_Rol_Permiso INT AUTO_INCREMENT PRIMARY KEY NOT NULL,
    id_Rol INT,
    id_Permiso INT,
    FOREIGN KEY (id_Rol) REFERENCES Roles(id_Rol),
    FOREIGN KEY (id_Permiso) REFERENCES Permisos(id_Permiso)
);
